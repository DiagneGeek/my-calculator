const globalDetails = [

   `
      <img src="../images/html.png">
    `,
    
    `
     <img src="../images/css.png">
    `
]
export default globalDetails;
