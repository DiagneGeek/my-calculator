
function menu(racs) {
    let bar = document.querySelector(".menuBar")   
    for(let i in racs){
      racs[i].addEventListener("click", () => {
        bar.style.left = racs[i].offsetLeft + "px";
        bar.style.width = racs[i].offsetWidth + "px";      
      })
    }
}
menu(document.querySelectorAll(".rac"));