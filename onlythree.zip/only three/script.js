
function setScrollIndicator(el) {
  let bodyHeight = document.body.offsetHeight;
  let clientPosition = Math.round(window.scrollY+600);
  let pourcentage = (clientPosition*100)/bodyHeight;
  
  el.style.width = Math.round(pourcentage) + "%";
}
document.body.onscroll = () => setScrollIndicator(document.querySelector(".scroll-indicator"));


function shortcut(shortcutLink, index) {
  shortcutLink.onclick = () => {
  document.querySelectorAll(".lang")[index].scrollIntoView({behavior:"smooth"})
  }
}
 document.querySelectorAll(".linksRac .rac").forEach(function (shortcutLink,index) {
   shortcut(shortcutLink,index);
})


function toggleMenu(bars,links) {
 let menuBtn = document.querySelector(".affMenuBtn");
  menuBtn.onclick = () => {
    bars[0].classList.toggle("rotate1")
    bars[1].classList.toggle("hide");
    bars[2].classList.toggle("rotate2")
    links.classList.toggle("racVisible");
    links.onclick = () => menuBtn.click()
  }
}
 toggleMenu(document.querySelectorAll(".affMenuBtn span"),document.querySelector(".linksRac"))











